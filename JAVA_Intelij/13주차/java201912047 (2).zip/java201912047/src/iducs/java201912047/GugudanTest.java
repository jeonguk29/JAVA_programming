package iducs.java201912047;

public class GugudanTest {
    public static void main(String[] args) {
        //GugudanSuper gugudanSuper = new GugudanSuper();
        //gugudanSuper.printDan(5);
        Gugudan gugudan = new Gugudan();
        gugudan.printAll(4);
        //gugudan.printAll(7);
        //gugudan.printAll();
    }
}
