package iducs.java201912047.inheritance;

import javax.print.DocFlavor;

//public class MyString extends String { // string 는 파널 클래스라 상속 불가
//}
