package iducs.java201912047.pims;
import iducs.java201912047.pims.controller.pimcontroller;


public class Main {
    public static void main(String[] args) {
    pimcontroller pimcontroller = new pimcontroller();
    pimcontroller.dispatch();

    }

}
