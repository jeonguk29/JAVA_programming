package iducs.java201912047.polymorphism;

public class SUperNumber {
    String string = "induk"; // 다른패키지에 있는 애들은 못씀 클래스 이름은 같아도
    public String pubStr = "comso";

}
