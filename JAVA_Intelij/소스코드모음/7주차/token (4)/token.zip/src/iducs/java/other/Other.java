package iducs.java.other;

import iducs.java.token.Car;

public class Other extends Car {
    @Override
    public void move() {
        super.move(); // 현재 클래스의 상위클래스를 의미함
        System.out.println("Other가 이동한다");
    }
}
